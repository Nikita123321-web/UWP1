﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;                                   //библиотеки 
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace calc //имя проекта
{
  
    public sealed partial class MainPage : Page //c#+XAML взаимодействие
    {
        public MainPage() //главная страница
        {
            this.InitializeComponent();// метод инициализации компонентов

            result.Text = 0.ToString();
        }

        private void AddNumberToResult (double number) //метод класса+ название
        {
            if (char.IsNumber(result.Text.Last()))
            {
                if (result.Text.Length == 1 && result.Text == "0") //Возвращает число символов в тексте на номер
                {
                    result.Text = string.Empty;
                }
                result.Text += number;
            }
            else
            {
                if (number != 0)
                {
                    result.Text += number;
                }
            }
        }

        enum Operation  { MINUS=1, PLUS=2, DIV=3, TIMES=4, NUMBER=5 } //Тип перечисления, связанные с уникальными целочисленными значениями.
        private void AddOperationToResult(Operation operation) ////метод класса+ название
        {
            if (result.Text.Length == 1 && result.Text == "0") return; //Возвращает число символов в тексте на операции

            if (!char.IsNumber(result.Text.Last())) //условие
            {
                result.Text = result.Text.Substring(0, result.Text.Length-1);
            }
            switch (operation)//множественный выбор свитч с условиями/(кейсы)
            {
                case Operation.MINUS: result.Text += "-"; break;
                case Operation.PLUS: result.Text += "+"; break;
                case Operation.DIV: result.Text += "/"; break;
                case Operation.TIMES: result.Text += "x"; break;     

            }
        }


        private void btn7_Click(object sender, RoutedEventArgs e)
        {

            AddNumberToResult(7);  //кнопки привязаны +закрытый AddNumberToResult метод 

        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(8); //кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(9);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btnDiv_Click(object sender, RoutedEventArgs e)
        {
            AddOperationToResult(Operation.DIV);
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(4);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(5);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(6);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btnTimes_Click(object sender, RoutedEventArgs e)
        {
            AddOperationToResult(Operation.TIMES);
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(1);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(2);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(3);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btnMinus_Click(object sender, RoutedEventArgs e)
        {
            AddOperationToResult(Operation.MINUS);
        }

        
        private class Operand//закрытый класс для элементов только внутри него 
        {

            public Operation operation = Operation.NUMBER;
            public double value = 0;

            public Operand left = null;
            public Operand right = null;
        
        }

        private Operand BuildTreeOperand()
        {

            Operand tree = null;

            string expression = result.Text;
            if (!char.IsNumber(expression.Last()))
            {

                expression = expression.Substring(0, expression.Length - 1);

             }


            string numberStr = string.Empty;
            foreach (char c in expression.ToCharArray())
            {

                if (char.IsNumber(c) || c == '.' || numberStr == string.Empty && c == '-') //условие с логич значением &(и) |(или)
                {
                    numberStr += c;

                }
                else
                {

                    AddOperandToTree(ref tree, new Operand() { value = double.Parse(numberStr) });
                    numberStr = string.Empty;


                    Operation op = Operation.MINUS; //Default
                    switch (c) //множественный выбор свитч с условиями/(кейсы)
                    {

                        case '-': op = Operation.MINUS; break;
                        case '+': op = Operation.PLUS; break;
                        case '/': op = Operation.DIV; break;
                        case 'x': op = Operation.TIMES; break;
                    }

                    AddOperandToTree(ref tree, new Operand() { operation = op});
                }
            
            }

            AddOperandToTree(ref tree, new Operand() { value = double.Parse(numberStr) }); // метод parse 

            return tree;


        }


        private void AddOperandToTree(ref Operand tree, Operand elem)
        {

            if (tree == null)
            {
                                   //условия 
                tree = elem;
            }
            else 
            {

                if (elem.operation < tree.operation)
                {

                    Operand auxTree = tree;
                    tree = elem;
                    elem.left = auxTree;
                }
                else
                {

                    AddOperandToTree(ref tree.right, elem);

                }    

            }
        
        }

        private double CALC(Operand tree)
        {
            if (tree.left == null && tree.right == null)
            {
                return tree.value;

            }
            else 
            {
                double subResult = 0;
                switch (tree.operation) //множественный выбор свитч с условиями/(кейсы)
                                        //условия
                {

                    case Operation.MINUS: subResult = CALC(tree.left) - CALC(tree.right); break;
                    case Operation.PLUS: subResult = CALC(tree.left) + CALC(tree.right); break;
                    case Operation.DIV: subResult = CALC(tree.left) / CALC(tree.right); break;
                    case Operation.TIMES: subResult = CALC(tree.left) * CALC(tree.right); break;
                }
                return subResult;
          }

        }

        private void btnEqual_Click(object sender, RoutedEventArgs e)
        {
            
            if (string.IsNullOrEmpty(result.Text)) return;

            Operand tree = BuildTreeOperand();

            double value = CALC(tree);

            result.Text = value.ToString();
        
        }


        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            AddNumberToResult(0);//кнопки привязаны +закрытый AddNumberToResult метод 
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            result.Text = 0.ToString();//обнуления значения при нажатии на кнопку 
        }

        private void btnPlus_Click(object sender, RoutedEventArgs e)
        {
            AddOperationToResult(Operation.PLUS);//привязан к нашему методу
        }
    }
}